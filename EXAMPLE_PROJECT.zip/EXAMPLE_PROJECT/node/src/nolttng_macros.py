# This file is used by tools/js2c.py to preprocess out the LTTNG symbols in
# builds that don't support LTTNG. This is not used in builds that support
# LTTNG.
macro LTTNG_HTTP_CLIENT_REQUEST(x) = ;
macro LTTNG_HTTP_CLIENT_RESPONSE(x) = ;
macro LTTNG_HTTP_SERVER_REQUEST(x) = ;
macro LTTNG_HTTP_SERVER_RESPONSE(x) = ;
macro LTTNG_NET_SERVER_CONNECTION(x) = ;
macro LTTNG_NET_STREAM_END(x) = ;
